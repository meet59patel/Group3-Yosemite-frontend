## IT314 - Software Engineering
### Lab 9 - Static Analysis Tools
### Meet Patel - 201801415
##### Tool used for Static Analysis: JSLint
(Programming language: JavaScript)

##### Code where Static Analysis performed: See `JSLint-code` folder in current directory.
Code Source: [douglascrockford/JSLint](https://github.com/douglascrockford/JSLint)

### Testing Instructions:
- Prerequisites: NodeJS and npm
- Install [JSLint](https://www.npmjs.com/package/jslint) (tool for static analysis) using: `npm i -g jslint`
- Run: `jslint '**/*.js'` in shell to execute linter on all JavaScript files in current and child directories

### Results:
<img width="777" alt="image" src="https://user-images.githubusercontent.com/45785817/114977774-e133e880-9ea5-11eb-8c75-5d8238e64d86.png">