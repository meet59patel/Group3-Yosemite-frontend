//language : c++
//Sen assignment code with more than 1000 lines

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>

#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>


using namespace std;


#define SCD(t) scanf("%d",&t)
#define SCLD(t) scanf("%ld",&t)
#define SCLLD(t) scanf("%lld",&t)
#define SCC(t) scanf("%c",&t)
#define SCS(t) scanf("%s",t)
#define SCF(t) scanf("%f",&t)
#define SCLF(t) scanf("%lf",&t)
#define MEM(a, b) memset(a, (b), sizeof(a))
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define all(cont) cont.begin(), cont.end()
#define rall(cont) cont.end(), cont.begin()
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define IN(A, B, C) assert( B <= A && A <= C)
#define MP make_pair
#define PB push_back
#define INF (int)1e9
#define EPS 1e-9
#define PI 3.1415926535897932384626433832795
#define MOD 1000000007
#define read(type) readInt<type>()
const double pi=acos(-1.0);
typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<PII> VII;
typedef vector<VI> VVI;
typedef map<int,int> MPII;
typedef set<int> SETI;
typedef multiset<int> MSETI;
typedef long int int32;
typedef unsigned long int uint32;
typedef long long int int64;
typedef unsigned long long int  uint64;

class node{
	public:
		int data;
		node* next;
	
	node(int d)   //constructor
	{
		data=d;
		next=NULL;
	}
};
void insertAtHead(node* &head,int d)
{
	if(head==NULL)
	{
		head = new node(d);
		return;
	}
	node* n = new node(d);
	n->next=head;
	head=n;
}
void print(node*head)
{
	while(head!=NULL)
	{
		cout<<head->data<<endl;
		head=head->next;
	}
}
int length(node* head)
{
	int count=0;
	while(head!=NULL)
	{
		count++;
		head=head->next;
	}
	return count;
}
void insertAtTail(node*&head, int d)
{
	if(head==NULL)
	{
		head = new node(d);
		return;
	}
	node*tail = head;
	while(tail->next!=NULL)
	{
		tail = tail->next;
	}
	tail->next = new node(d);
	return;
}

void insertInMiddle(node* &head,int d,int p)
{
	if(head==NULL or p==0)
	{
		insertAtHead(head,d);
		return;
	}
	else if(p>length(head))
	{
		insertAtTail(head,d);
		return;
	}
	else
	{
		int jump=1;
		node* temp=head;
		while(jump<=p-1)
		{
			temp=temp->next;
			jump++;
		}
		
		node* n=new node(d);
		n->next=temp->next;
		temp->next=n;
	}
	
}
void deleteHead(node* &head)
{
	if(head==NULL)
	{
		return;
	}
	node*temp = head->next;
	delete head;
	head=temp;
}
bool search(node* head, int key)
{
	if(head==NULL)
	{
		return false;
	}
	node* temp=head;
	while(temp!=NULL)
	{
		if(key==temp->data)
		{
			return true;
		}
		temp = temp->next;
	}
	return false;
}
node* take_input()
{
	int d;
	cin>>d;
	node* head=NULL;
	while(d!=-1)
	{
		insertAtHead(head,d)
		cin>>d
	}
	
	/* if we are taking input from a file then
	while(cin>>d)
	{
		insertAtHead(head,d);
	}
	*/
	return head;
}

ostream& operator<<(ostream &os, node* head)
{
	print(head);
	return os;  //return cout so that we could execute cout<<head<<head2<<....<<headn;
}
istream& operator>>(istream &is, node* &head)
{
	head = take_input();
	return is;
}

void reverse(node* &head) //reverse a linked list
{
	node* c=head;
	node* p=NULL;
	node* n;
	while(c!=NULL)
	{
		n = c->next;
		c->next = p;
		p = c;
		c=n;
	}
	head=p;
}

bool detectCycle(node*head)
{
	node* slow=head;
	node*fast = head;
	while(fast!=NULL and fast->next!=NULL)
	{
		fast = fast->next->next;
		slow = slow->next;
		if(fast==slow)
		{
			return true;
		}
	}
	return false;
}

bool is_prime(int n)
{
	if(n==1)
	{
		return false;
	}
	if(n==2)
	{
		return true;
	}
	for(int i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
			return false;
		}
	}
	return true;
}

void prime_seive(int *p)
{
	//first mark all odd numbers as prime_seive
	for(int i=3;i<=1000000;i+=2)
	{
		p[i]=1;
	}
	for(long long i=3;i<=1000000;i+=2)
	{
		//if the current number is not marked(i.e prime)
		if(p[i]==1)
		{
			//mark all the multiples of i as non prime
			for(long long j=i*i;j<=1000000;j+=i)
			{
				p[j]=0;
			}
		}
	}
	//special case
	p[2]=1;
	p[1]=p[0]=0;
	
}

template<typename T,typename U>
class Stack{
	private:
	vector<T> v;
	vector<U> v2;
	public:
	void push(T data)
	{
		v.push_back(data);
	}
	bool empty()
	{
		return v.size()==0;
	}
	void pop()
	{
		if(!empty())
		{
			v.pop_back();
		} 
	}
	T top()
	{
		return v[v.size()-1];
	}
	
};

void StockSpan(int span[],int prices[],int n)
{
	stack<int> s;
	s.push(0);
	span[0] = 1;
	for(int i=1;i<n;i++)
	{
		int current = prices[i];
		while(!s.empty() and current>=prices[s.top()])
		{
			s.pop();
		}
		if(!s.empty())
		{
			span[i] = i - s.top();
		}
		else
		{
			span[i] = i+1;
		}
		s.push(i);
		
	}
}

class Graph {
private:
      int **adjMatrix;
      int vertexCount;
	  // below attributes are for Prims

	  int *key;
	  int *distance;
	  int *parent;

public:
    Graph(int vertexCount);
    ~Graph();
	void addEdgeDirectedWeight(int i, int j, int cost);
	void removeEdgeUndirected(int i, int j);
    int isEdge(int i, int j);
    void display();
	void initializeState();

	void showBasicInfo();
	void Dijkstra(int startNode);
	int isAllKeyTrue();  //0 means not MST, 1 means MST
	int findMinDistanceNode();

};
Graph::Graph(int vertexCount) {
    this->vertexCount = vertexCount;

	this->key = new int[vertexCount];
	this->distance = new int[vertexCount];
	this->parent = new int[vertexCount];

    adjMatrix = new int*[vertexCount];
    for (int i = 0; i < vertexCount; i++) {
        adjMatrix[i] = new int[vertexCount];
           for (int j = 0; j < vertexCount; j++)
              adjMatrix[i][j] = 0;
    }
}
Graph::~Graph() {
    for (int i = 0; i < vertexCount; i++)
         delete[] adjMatrix[i];
            delete[] adjMatrix;
}
void Graph::initializeState(){
	for(int i=0; i<this->vertexCount; i++){
		this->key[i] = 0; // 0=not in MST, 1=yes in MST
		this->distance[i]= INT_MAX; //initially distance is Max int
		this->parent[i] = -1;  // -1=no parent, else parent info
		                       //
	}
}
void Graph::addEdgeDirectedWeight(int i, int j, int cost) {
    if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount) {
		adjMatrix[i][j] = cost;
    }
}
void Graph::removeEdgeUndirected(int i, int j) {
    if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount) {
		adjMatrix[i][j] = 0;
		adjMatrix[j][i] = 0;
    }
}
int Graph::isEdge(int i, int j) {
    if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount)
        return adjMatrix[i][j];
    else{
		cout<<"Invalid vertex number.\n";
		return 0;
	}
}
void Graph::display(){
    int  u,v; //vertex
	cout<<"\t   ";
	for(u=0; u<vertexCount; u++){
		cout<<u<<" ";
	}
    for(u=0; u<vertexCount; u++) {
        cout << "\nNode[" << (char) (u+48) << "] -> ";
        for(v=0; v<vertexCount; ++v) {
            cout << " " << adjMatrix[u][v];
        }
    }
    cout << "\n\n";
}
void Graph::showBasicInfo(){
	for(int i=0; i<vertexCount; i++){
		cout<<"node: "<<i<<" Key: "<<key[i]
			<<" distance: "<<distance[i]<<" parent: "<<parent[i]<<"\n";
	}
}
int Graph::isAllKeyTrue(){
	for(int i=0; i<this->vertexCount; i++){
		if(this->key[i]==0)
			return 0; // not MST yet
	}
	return 1; // MST done

}
int Graph::findMinDistanceNode(){
	int minDistant=INT_MAX;
	int minDistantNode;

	for(int i=0; i<vertexCount; i++) {
		if(minDistant > this->distance[i] && this->key[i]==0)
		{ //0 means that node is not in MST
			minDistantNode = i;
			minDistant = this->distance[i];
			//cout<<"min: "<<minDistantNode<<"\n";
		}
	}
	//cout<<"Min Distant Node: "<<minDistantNode<<" Cost: "<<minDistant<<"\n";
	return minDistantNode;
}

void Graph::Dijkstra(int startNode){
	cout<<"\nDijkstra Shortest Path starts . . . \n";

	// initialization is done before call this method
	this->distance[startNode]=0; //start node's distance is 0
	int minDistanceNode, i;

	// 0 means Shortest path calculation is not done yet.
	while(!this->isAllKeyTrue()){
		//cout<<"-------------------------------\n";
		minDistanceNode = findMinDistanceNode();
		this->key[minDistanceNode] = 1;  // this node's shortes path is done

		cout<<"Shortest Path: "<<this->parent[minDistanceNode]<<"->"
			<<minDistanceNode<<", Destination Node's cost is: "<<distance[minDistanceNode]<<"\n";


		for(i=0; i<vertexCount; i++){
			if(this->isEdge(minDistanceNode, i) && this->key[i]==0 ){
                //Below is the code for relaxation
				if(this->distance[i] > this->distance[minDistanceNode]
					                   + adjMatrix[minDistanceNode][i]){
					this->distance[i] = this->distance[minDistanceNode]
						                + adjMatrix[minDistanceNode][i];
					this->parent[i] = minDistanceNode;
				}
			}
		}
		//this->showBasicInfo(); // To visualize more clearly
		// you can comment this to only show the edges of MST
	}

}

bool isbalanced(char *s)
{
	stack<char> st;
	char ch;
	for(int i=0;s[i]!='\0';i++)
	{
		ch = s[i];
		if(ch=='(')
		{
			st.push(ch);
		}
		else if(ch==')')
		{
			if(st.empty() or st.top()!='(')
			{
				return false;
			}
			st.pop();
		}
	}
	return st.empty();
}

int compare(int a, int b)
{
	return a>b;
}

void selection_sort(int a[], int n)
{
	int minIndex;
	for(int i=0;i<n-1;i++)
	{
		minIndex = i;
		for(int j=i+1;j<n;j++)
		{
			
			if(a[j]<a[minIndex])
			{
				minIndex=j;
				
			}
		}
		swap(a[i],a[minIndex]);
	}
}

void bubble_sort(int a[], int n)
{
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j+1]<a[j])
			{
				swap(a[j],a[j+1]);
			}
		}
	}
}

void insertion_sort(int a[], int n)
{
	int key,j;
	for(int i=1;i<n;i++)
	{
		key = a[i];
		j=i-1;
		while(j>=0 and a[j]>key)
		{
			a[j+1]=a[j];
			j=j-1;
		}
		a[j+1]=key;
	}
}

void print_func(int a[], int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
	cout<<"\n";
}


void buildTree(int *tree,int *a,int index,int s,int e)
{
	if(s>e)
		return ;
	if(s==e)
	{
		tree[index]=a[s];
		return ;
	}
	int m = (s+e)/2;
	buildTree(tree,a,2*index,s,m);
	buildTree(tree,a,2*index+1,m+1,e);
	tree[index] = min(tree[2*index],tree[2*index+1]);
}

void updateNode(int *tree,int index,int s,int e,int pos,int val)
{
	if(pos<s || pos>e)
		return ;
	if(s==e)
	{
		tree[index] = val;
		return ;
	}
	int m = (s+e)/2;
	updateNode(tree,2*index,s,m,pos,val);
	updateNode(tree,2*index+1,m+1,e,pos,val);
	tree[index] = min(tree[2*index],tree[2*index+1]);
	return;
}

void updateRange(int *tree,int *lazy,int index,int s,int e,int rs,int re,int inc)
{
	if(lazy[index]!=0)
	{
		tree[index] += lazy[index];
		if(s!=e)
		{
			lazy[2*index] += lazy[index];
			lazy[2*index+1] += lazy[index];
		}
		lazy[index]=0;
	}

	if(s>e || s>re || e<rs)
		return;

	if(s>=rs && e<=re)
	{
		tree[index] += inc;
		if(s!=e)
		{
			lazy[2*index]+=inc;
			lazy[2*index+1] +=inc;
		}
		return;
	}

	int m= (s+e)/2;
	updateRange(tree,lazy,2*index,s,m,rs,re,inc);
	updateRange(tree,lazy,2*index+1,m+1,e,rs,re,inc);
	tree[index] = min(tree[2*index],tree[2*index+1]);
}

int query(int *tree,int *lazy,int index,int s,int e,int rs,int re)
{
	if(lazy[index]!=0)
	{
		tree[index] += lazy[index];
		if(s!=e)
		{
			lazy[2*index] += lazy[index];
			lazy[2*index+1] += lazy[index];
		}
		lazy[index]=0;
	}

	if(s>e || s>re || e<rs)
		return INT_MAX;
	if(s>=rs && e<=re)
		return tree[index];
	int m= (s+e)/2;
	int left=query(tree,lazy,2*index,s,m,rs,re);
	int right = query(tree,lazy,2*index+1,m+1,e,rs,re);
	return min(left,right);

}

void spiral_print(int a[1000][1000], int m, int n)
{
	cout<<"Spiral Print"<<endl;
	int start_row=0;
	int start_col=0;
	int end_row=m-1;
	int end_col=n-1;
	while(start_row<=end_row and start_col<=end_col)
	{
		for(int i=start_col;i<=end_col;i++)
		{
			cout<<a[start_row][i]<<" ";
		}
		start_row++;
		for(int i=start_row;i<=end_row;i++)
		{
			cout<<a[i][end_col]<<" ";
		}
		end_col--;
		if(end_row>=start_row)
		{
		
		for(int i=end_col;i>=start_col;i--)
		{
			cout<<a[end_row][i]<<" ";
		}
		end_row--;
		}
		if(end_col>=start_col)
		{
		
		for(int i=end_row;i>=start_row;i--)
		{
			cout<<a[i][start_col]<<" ";
		}
		start_col++;
		}
	}
}

void removeDuplicates(char a[])
{
	int l = strlen(a);
	if(l==1 or l==0)
	{
		return;
	}
	int prev = 0;
	for(int current=1;current<l;current++)
	{
		if(a[prev]!=a[current])
		{
			prev++;
			a[prev]=a[current];
		}
	}
	a[prev+1]='\0';
	return;
}

int sumOfAllSub(int **arr,int rows,int cols)
{
	int sum=0;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			int tl = (i+1)*(j+1);
			int br = (rows-i)*(cols-j);
			sum += (tl*br)*arr[i][j];
		}
	}
	return sum;
}

int BinarySearch(int a[], int n,int key)
{
	int s = 0;
	int e = n-1;
	while(s<=e)
	{
		int mid = (s+e)/2;
		if(a[mid]==key)
		{
			return mid;
		}
		else if(a[s]<=a[mid])
		{
			if(a[s]<=key and a[mid]>=key)
			{
				e= mid-1;
			}
			else
			{
				s=mid+1;
			}
		}
		else
		{
			if(a[mid]<=key and a[e]>=key)
			{
				s=mid+1;
			}
			else
			{
				e=mid-1;
			}
		}
	}
}

int d;
struct btnode
{
	int *key;
	btnode **child;
};

bool check_leaf(btnode* T)
{
	int flag=0;
	for(int i=0;i<2*d+1;i++)
	if(T->child[i]!=NULL)
	flag=1;
	if(flag==0)
	return (1);
	else
	return (0);
}
void add_to_node(btnode* old_node,int k,btnode* &new_node,int pos)
{
	int i,j;
	for(i=0;i<2*d&&old_node->key[i]!=-1;i++);
	for(j=i-1;j>=pos&&old_node->key[j]>k;j--)
	{
		old_node->key[j+1]=old_node->key[j];
		old_node->child[j+2]=old_node->child[j+1];
	}
	old_node->key[pos]=k;
	old_node->child[pos+1]=new_node;
}
void create_newnode(btnode* &T)
{
	int i;
	T=new btnode;
	T->key=new int[2*d];
	T->child=new btnode*[2*d+1];
	for(i=0;i<2*d;i++) T->key[i]=-1;
	for(i=0;i<2*d+1;i++) T->child[i]=NULL;
}
void nodesplit(btnode* old_node,btnode* &new_node,int &k,int pos)
{
	btnode* N=NULL;
	create_newnode(N);
	if(pos<=d)
	{
		for(int i=d;i<2*d;i++)
		{
			N->key[i-d]=old_node->key[i];
			N->child[i-d+1]=old_node->child[i+1];
			old_node->key[i]=-1;
			old_node->child[i+1]=NULL;
		}
		N->child[0]=old_node->child[d];
		add_to_node(old_node,k,new_node,pos);
	}
	else
	{
		for(int i=d+1;i<2*d;i++)
		{
			N->key[i-(d+1)]=old_node->key[i];
			N->child[i-d]=old_node->child[i+1];
			old_node->key[i]=-1;
			old_node->child[i+1]=NULL;
		}
		N->child[0]=old_node->child[d+1];
        old_node->child[d+1]=NULL;
		add_to_node(N,k,new_node,pos-(d+1));
	}
	k=old_node->key[d];
	old_node->key[d]=-1;
	new_node=N;
}
int setflag(btnode T,int &k,btnode* &new_node)
{
	int pos;
	if(T==NULL)
	{
		return (1);
	}
	for(pos=0;pos<2*d&&T->key[pos]!=-1;pos++)
	{
		if(k<T->key[pos]) break;
	}
	if(check_leaf(T))
	{
		if(T->key[2*d-1]==-1)
		{
			add_to_node(T,k,new_node,pos);
			return (0);
		}
		else
		{
			nodesplit(T,new_node,k,pos);
			return (1);
		}
	}
	else
	{
		int flag=setflag(T->child[pos],k,new_node);
		if(flag==1)
		{
			if(T->key[2*d-1]==-1)
			{
				add_to_node(T,k,new_node,pos);
				return (0);
			}
		    else
		    {
			    nodesplit(T,new_node,k,pos);
			    return (1);
		    }
		}
	}
}
btnode* create_root(btnode* T,btnode* new_node,int k)
{
	btnode* root=NULL;
        create_newnode(root);
	    root->key[0]=k;
		root->child[0]=T;
		root->child[1]=new_node;
		return (root);
}
void insert(btnode* &T,int k,btnode* new_node)
{
	btnode* root=NULL;
	int flag=setflag(T,k,new_node);
	if(flag) T=create_root(T,new_node,k);
}

bool is_possible(int a[],int n,int c,int min_distance)
{
	int last_cow = a[0];
	int count = 1;
	for(int i=1;i<n;i++)
	{
		if((a[i]-last_cow)>=min_distance)
		{
			last_cow = a[i];
			count++;
			if(count==c)
			{
				return true;
			}
		}
	}
	return false;
}

int largest_minimum_distance(int a[],int n,int c)
{
	int s = 0;
	int e = a[n-1] - a[0];
	int ans = 0;
	while(s<=e)
	{
		int mid = (s+e)/2;
		bool cowRakhPaya = is_possible(a,n,c,mid);
		if(cowRakhPaya)
		{
			ans = mid;
			
			s = mid+1;
		}
		else
		{
			e=mid-1;
		}
	}
	return ans;
}

int minPages(int a[],int n,int m)
{
	if(n<m)
	{
		return -1;
	}
	long long sum = 0;
	for(int i=0;i<n;i++)
	{
		sum+=a[i];
	}
	int s= a[n-1];
	int e = sum;
	int ans = INT_MAX;
	while(s<=e)
	{
		int mid=(s+e)/2;
		if(is_possible(a,n,m,mid))
		{
			ans = min(mid,ans);
			e = mid - 1;
		}
		else
		{
			s = mid+1;
		}
	}
	return ans;
	
}



int main()
{
	node* head;
	node* head2;
	cin>>head>>head2;
	reverse(head);
	cout<<head<<head2;
	insertAtHead(head,5);
	insertAtHead(head,2);
	insertAtHead(head,1);
	insertAtHead(head,0);
	
	insertInMiddle(head,4,3);
	insertAtTail(head,7);
	cout<<head;
	
	if(search(head,6))
	{
		cout<<"element found";
	}
	else
	{
		cout<<"Not found";
	}
}


